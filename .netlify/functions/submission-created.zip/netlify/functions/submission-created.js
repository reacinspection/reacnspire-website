var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/submission-created.mjs
var submission_created_exports = {};
__export(submission_created_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(submission_created_exports);
var handler = async (event) => {
  let payload;
  try {
    payload = JSON.parse(event.body).payload;
  } catch {
    return { statusCode: 200, body: "no payload" };
  }
  if (!payload || payload.form_name !== "taller-registro") {
    return { statusCode: 200, body: "ignored" };
  }
  const data = payload.data || {};
  const email = (data.email || "").trim();
  const nombre = (data.nombre || "").trim();
  if (!email) return { statusCode: 200, body: "no email" };
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.FROM_EMAIL;
  if (!apiKey || !from) {
    console.log("submission-created: RESEND_API_KEY/FROM_EMAIL not set - skipping confirmation email");
    return { statusCode: 200, body: "not configured" };
  }
  const saludo = nombre ? `Hola ${nombre},` : "Hola,";
  const html = `
  <div style="font-family:Segoe UI,Arial,sans-serif;max-width:560px;margin:0 auto;color:#1f2937;">
    <div style="background:#0D1F3C;padding:24px 28px;border-radius:12px 12px 0 0;">
      <h1 style="color:#fff;font-size:20px;margin:0;">\xA1Registraci\xF3n recibida!</h1>
    </div>
    <div style="border:1px solid #e5e7eb;border-top:none;border-radius:0 0 12px 12px;padding:24px 28px;">
      <p>${saludo}</p>
      <p>Gracias por registrarse para nuestro <strong>Taller de Seguridad GRATIS \u2014 \xABSeguridad en el Lugar de Trabajo\xBB</strong>. Aqu\xED est\xE1n los detalles:</p>
      <table style="border-collapse:collapse;margin:16px 0;font-size:15px;">
        <tr><td style="padding:6px 14px 6px 0;color:#6b7280;">Fecha</td><td style="font-weight:700;">Martes 18 de agosto de 2026</td></tr>
        <tr><td style="padding:6px 14px 6px 0;color:#6b7280;">Hora</td><td style="font-weight:700;">10:00 AM \u2013 11:30 AM (EST)</td></tr>
        <tr><td style="padding:6px 14px 6px 0;color:#6b7280;">Plataforma</td><td style="font-weight:700;">Microsoft Teams (en l\xEDnea)</td></tr>
      </table>
      <p><strong>Le enviaremos el enlace de Microsoft Teams por este mismo correo antes del evento.</strong> No necesita hacer nada m\xE1s por ahora.</p>
      <p style="font-size:13px;color:#6b7280;margin-top:22px;">Kendra REAC Consultant, Inc.<br>
      \xBFPreguntas? Responda a este correo o llame al (407) 516-5393.</p>
    </div>
  </div>`;
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: "Bearer " + apiKey, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: [email],
        subject: "Confirmaci\xF3n \u2014 Taller de Seguridad GRATIS (18 de agosto)",
        html
      })
    });
    if (!res.ok) console.log("submission-created: Resend error", res.status, await res.text().catch(() => ""));
  } catch (e) {
    console.log("submission-created: send failed", e && e.message);
  }
  return { statusCode: 200, body: "ok" };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
